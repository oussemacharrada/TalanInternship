import { Injectable } from '@angular/core';
import { HttpClient,HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Formation} from '../formation.model';
const baseUrl = 'http://localhost:8080/api/formations';
@Injectable({
  providedIn: 'root'
})
export class FormationService {

  constructor(private http: HttpClient) { }
  getAll(): Observable<any> {
    return this.http.get(baseUrl);
  }

  get(id: any): Observable<any> {
    return this.http.get(`${baseUrl}/${id}`);
  }

  create(data: Formation): Observable<any> {
    return this.http.post(baseUrl, data);
  }

 
  update( data: any): Observable<any> {
    return this.http.put(`${baseUrl}/${data.id}`, data);
  }
  delete(id:any): Observable<any> {
    return this.http.delete(`${baseUrl}/${id}`);
  }
}
