import { Formation } from './formation.model';

describe('Formation', () => {
  it('should create an instance', () => {
    expect(new Formation()).toBeTruthy();
  });
});
