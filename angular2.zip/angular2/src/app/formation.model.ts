export class Formation {

    id?: any;
  formateur?: string;
  description?: string;
  theme?: string;
  dateheure?:string;
}
