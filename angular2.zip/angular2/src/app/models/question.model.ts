export class Question {

  id?: any;
  category?: string;
  description?: string;
  published?: boolean;
}
