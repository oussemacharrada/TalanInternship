import { Component, Inject, OnInit , ViewChild } from '@angular/core';
import { Question } from '../../models/question.model';
import { QuestionService } from '../../services/question.service';
import { faEdit } from '@fortawesome/free-solid-svg-icons';
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import { faComment } from '@fortawesome/free-solid-svg-icons';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute, Router } from '@angular/router';
import { faPaperclip} from '@fortawesome/free-solid-svg-icons';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-question-list',
  templateUrl: './question-list.component.html',
  styleUrls: ['./question-list.component.scss']
})
export class QuestionListComponent implements OnInit {
term:any;
description :any;
faPaperclip=faPaperclip;
  faEdit = faEdit;
  faTrashAlt = faTrashAlt;
  faComment=faComment;
  faUserCircle=faUserCircle;
  questions?: Question[];
  currentIndex = -1;
  category = '';
  currentQuestion: Question = {
    category: '',
    description: '',
    published: false
  };
  question={
    category :'',
    description:'',
    published: false
  };
  constructor(private questionService: QuestionService ,private route: ActivatedRoute,
    private router: Router ) { 
    
  }

  ngOnInit(): void {
    this.retrieveQuestions();
    this.getQuestion(this.route.snapshot.params.id);
    this.selectQuestion(this.route.snapshot.params.id);
  }
  retrieveQuestions(): void {
    this.questionService.getAll()
      .subscribe(
        data => {
          this.questions = data;
          console.log(data);
        });  }
  newQuestion(): void {
    this.question = {
      category:'',
      description:'',
      published:false
    }
  };
  saveQuestion():void{
    const data = {
      category: this.question.category,
      description: this.question.description
    };
    this.questionService.create(data)
    .subscribe(
      response => {
        console.log(response);
        });
      location.reload();  
}
  getQuestion(id: any): void {
    this.questionService.get(id)
      .subscribe(
        data => {
          this.currentQuestion = data;
          console.log('getbyid',this.currentQuestion);
        });
  }
  selectQuestion(id: any): void {
    this.questionService.get(id)
      .subscribe(
        data => {
          this.currentQuestion= data;
          console.log('select question', data);
        });
  }
  updateQuestion1(){
    this.questionService.update(this.currentQuestion)
      .subscribe(
        response => {
          Swal.fire({
            text: 'Votre message a été bien modifié',
            icon: 'success',
            showCancelButton: true,
            confirmButtonText: 'ok!',
           })
          this.retrieveQuestions();
        });
      }
  deleteQuestion(id: any){
    this.questionService.delete(id).subscribe( data => {
      this.getQuestion(id);
      Swal.fire({
        text: 'Votre message a été supprimé avec succé',
        icon: 'success',
      })
      this.retrieveQuestions();
    });
  }}

