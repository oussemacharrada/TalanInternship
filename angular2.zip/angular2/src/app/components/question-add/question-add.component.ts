


import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { QuestionService } from '../../services/question.service';
import { Question } from '../../models/question.model';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-question-form',
  templateUrl: './question-form.component.html',
  styleUrls: ['./question-form.component.scss']
})
export class QuestionFormComponent implements OnInit {
  question={
    category :'',
    description:'',
    published: false
  };
 constructor(private questionService: QuestionService,
    private router: Router) { }
  ngOnInit(): void {
  }
  saveQuestion():void{
    const data = {
      category: this.question.category,
      description: this.question.description
    };
    this.questionService.create(data)
    .subscribe(
      response => {
        console.log(response);
        });
      location.reload();  
}}
