import { Component, OnInit } from '@angular/core';
import { faEdit } from '@fortawesome/free-solid-svg-icons';
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import { faComment } from '@fortawesome/free-solid-svg-icons';
import { faCalendar} from '@fortawesome/free-solid-svg-icons';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';

import { MatDatepickerModule } from '@angular/material/datepicker';
import { ActivatedRoute, Router } from '@angular/router';
import { faPaperclip} from '@fortawesome/free-solid-svg-icons';
import Swal from 'sweetalert2';
import { Formation } from '../../formation.model';
import { FormationService } from '../../services/formation.service';
import { DatePipe } from '@angular/common';
import { dateInputsHaveChanged } from '@angular/material/datepicker/datepicker-input-base';
import { NgbDatepicker } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-formation',
  templateUrl: './formation.component.html',
  styleUrls: ['./formation.component.scss']
})
export class FormationComponent implements OnInit {
  term:any;
  description :any;
  faCalendar=faCalendar;
  faPaperclip=faPaperclip;
    faEdit = faEdit;
    faTrashAlt = faTrashAlt;
    faComment=faComment;
    faUserCircle=faUserCircle;
    formations?: Formation[];
    currentIndex = -1;
    theme = '';
    currentFormation: Formation = {
      theme: '',
      description: '',
      formateur:'',
      dateheure:'',
      

       
    };
    formation={
      theme: '',
      description: '',
      formateur:'',
      dateheure:'',
    };
    formateur:any;
  constructor(private formationService: FormationService ,private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.retrieveFormations();
    this.getFormation(this.route.snapshot.params.id);
    this.selectFormation(this.route.snapshot.params.id);
  }
  retrieveFormations(): void {
    this.formationService.getAll()
      .subscribe(
        data => {
          this.formations = data;
          console.log(data);
        });  }
  newQuestion(): void {
    this.formation = {
      theme: '',
      description: '',
      formateur:'',
      dateheure:'',
    }
  };
  getFormation(id: any): void {
    this.formationService.get(id)
      .subscribe(
        data => {
          this.currentFormation= data;
          console.log('getbyid',this.currentFormation);
        });
  }
  selectFormation(id: any): void {
    this.formationService.get(id)
      .subscribe(
        data => {
          this.currentFormation= data;
          console.log('select question', data);
        });
  }
  updateFormation1(){
    this.formationService.update(this.currentFormation)
      .subscribe(
        response => {
          Swal.fire({
            text: 'Votre message a été bien modifié',
            icon: 'success',
            showCancelButton: true,
            confirmButtonText: 'ok!',
           })
          this.retrieveFormations();
        });
      }
  deleteFormation(id: any){
    this.formationService.delete(id).subscribe( data => {
      this.getFormation(id);
      Swal.fire({
        text: 'Votre message a été supprimé avec succé',
        icon: 'success',
      })
      this.retrieveFormations();
    });
  }}


