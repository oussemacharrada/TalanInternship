import { Component, OnInit } from '@angular/core';
import { Formation } from '../../formation.model';
import { FormationService } from '../../services/formation.service';
import { Router } from '@angular/router';
import { faCalendar} from '@fortawesome/free-solid-svg-icons';
@Component({
  selector: 'app-add-formation',
  templateUrl: './add-formation.component.html',
  styleUrls: ['./add-formation.component.scss']
})
export class AddFormationComponent implements OnInit {
  formation={
    theme: '',
    description: '',
    formateur:'',
    dateheure:'',
  };
  faCalendar=faCalendar;
  constructor(private formationService: FormationService,
    private router: Router) { }

  ngOnInit(): void {
  }
  saveFormation():void{
    const data = {
      theme: this.formation.theme,
      description: this.formation.description,
      formateur: this.formation.formateur,
      dateheure: this.formation.dateheure,
     
    };
    this.formationService.create(data)
    .subscribe(
      response => {
        console.log(response);
        });
      location.reload();  
}

}
