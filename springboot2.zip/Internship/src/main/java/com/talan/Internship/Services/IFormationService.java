package com.talan.Internship.Services;

import java.util.List;

import com.talan.Internship.Model.Formation;
import com.talan.Internship.responses.MessageResponse;

public interface IFormationService {
	
	public MessageResponse save(Formation formation);
	public MessageResponse delete(Integer id);
	public MessageResponse update(Formation question);
	public List<Formation> findAll();
	public Formation findById(Integer id );
	

}
