package com.talan.Internship.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.talan.Internship.Model.Formation;
import com.talan.Internship.Model.Question;
import com.talan.Internship.responses.MessageResponse;
import com.talan.Internship.serviceImpl.FormationServiceImpl;
import com.talan.Internship.serviceImpl.QuestionServiceImpl;

@CrossOrigin("*")
@RestController
@RequestMapping("/api")
public class FormationController {

	@Autowired
	private FormationServiceImpl formationServiceImpl;
	
	


	@GetMapping("/formations")
	public List<Formation> getAllFormations() {
	
			return formationServiceImpl.findAll();
}
	
	
	
			
			
	@GetMapping("/formations/{id}")
	public Formation getFormationById(@PathVariable("id") Integer id) {
		
			
			return formationServiceImpl.findById(id);
		
	}
	
	
	@PostMapping("/formations")
	public MessageResponse saveFormation(@RequestBody Formation formation) {
		return formationServiceImpl.save(formation);
	}
	@PutMapping("/formations/{id}")
	public MessageResponse update(@RequestBody Formation formation) {
		
		return formationServiceImpl.update(formation);
			
	}
	
	
	@DeleteMapping("/formations/{id}")
	public MessageResponse delete(@PathVariable("id") Integer id) {
		
		return formationServiceImpl.delete(id);
		
	}
	

}
