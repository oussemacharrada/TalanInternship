package com.talan.Internship.Repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.talan.Internship.Model.Formation;



public interface FormationRepository extends JpaRepository<Formation, Integer>{

	
}
