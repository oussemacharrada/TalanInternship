package com.talan.Internship.Model;
import java.util.ArrayList;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
		import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.Data;
		@Data
		@Entity
		@Table(name = "question")
		public class Question implements Comparable<Question> {

		   
		   
		    @Id
			@GeneratedValue(strategy = GenerationType.IDENTITY)
		    private Integer id;
			private String description;
			private String category;
			private boolean published;
			@Temporal(TemporalType.TIMESTAMP)
			@Column(nullable = false)
			
			private Date datecreated;
			
			@PrePersist
			private void onCreate() {
				datecreated = new Date();
			}
			@Override
			public int compareTo(Question arg0) {
				// TODO Auto-generated method stub
				return 0;
			}}
			

			

