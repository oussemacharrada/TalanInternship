package com.talan.Internship.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.talan.Internship.Model.Formation;
import com.talan.Internship.Model.Question;
import com.talan.Internship.Repository.FormationRepository;
import com.talan.Internship.Repository.QuestionRepository;
import com.talan.Internship.Services.IFormationService;
import com.talan.Internship.responses.MessageResponse;


@Service
public class FormationServiceImpl implements IFormationService {

	@Autowired
	private FormationRepository formationRepository;

	@Override
	public MessageResponse save(Formation formation) {
		formationRepository.save(formation);
		return new MessageResponse(true, "succes", "Operation effectuée avec succes");
	}	

	@Override
	public MessageResponse delete(Integer id) {
		formationRepository.deleteById(id);
         return new MessageResponse(true, "succes", "Operation effectuée avec succes");
	}

	@Override
	public MessageResponse update(Formation question) {
		formationRepository.save(question);
			return new MessageResponse(true, "succes", "Operation effectuée avec succes");	}

	@Override
	public List<Formation> findAll() {
		return formationRepository.findAll().stream().sorted(Comparator.comparing(Formation::getDatecreated).reversed()).collect(Collectors.toList());
	}

	@Override
	public Formation findById(Integer id) {
		return formationRepository.findById(id).orElse(null);}

}
